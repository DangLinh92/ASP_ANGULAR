export interface UserModel {
    id: string;
    email: string;
    firstName: string;  
    roles: string[];
    permissions: any;
}
