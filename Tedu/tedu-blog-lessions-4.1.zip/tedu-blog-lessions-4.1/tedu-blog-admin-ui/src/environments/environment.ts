export const environment = {
    production: false,
    API_URL: 'https://localhost:7004',
  };
  