﻿namespace TeduBlog.Core.Models.Content
{
    public class ReturnBackRequest
    {
        public string Reason { set; get; }
    }
}
