﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeduBlog.Core.Models.System
{
    public class CreateUpdateRoleRequest
    {
        public string Name { get; set; }
        public string DisplayName { get; set; }
    }
}
